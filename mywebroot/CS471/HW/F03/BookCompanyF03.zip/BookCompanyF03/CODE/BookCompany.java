
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Collections;
/**
 * BookCompany contains an inventory of Book.  
 * Book is a private nested class.
 * The sorting algorithm provided in Collections is used to sort
 * the inventory of books.
 * Inorder to use the provided sort(), the ordering of the Book objects 
 * are provided in the inner class Book.BookComparator.  Book.BookComparator
 * implements java.util.Comparator.
 **/
public class BookCompany {
    ArrayList inventory = new ArrayList(); // allows for duplicate books objects
    public void addBook(String title, int year) {
	inventory.add(new Book(title,year));
    }
    public void removeBook(String title, int year){
	Book book = new Book(title,year);
	int indexOf = inventory.indexOf(book);
	if (indexOf>-1) inventory.remove(indexOf);
    }
    /*** 
	sortInventory() uses the class method Collections.sort provided in
	the Java API. Collections.sort() sorts the specified 
	list according to the order induced by the specified comparator. 
	All elements in the list must be mutually comparable using 
	the specified comparator (that is, c.compare(e1, e2) must not throw a 
	ClassCastException  for any elements e1 and e2 in the list)."
	
    ***/
    /* sort() does not know which comparator() code will be used until runtime.
       The runtime environment dynamically dispatches to the correct code based
       on the currently executing object.  In this case it will be
       BookCompany.Book.comparator.
    */

    public void sortInventory(){
	// Since the comparator is bond at runtime, the user
	// can define many different "comparator" classes
	// and use any (or all) one of them at any time.
	Collections.sort(inventory,BookCompany.Book.comparator );
    }
    // Override toString()
    // This create a string of all Book objects in "inventory"
    public String toString(){
	return inventory.toString();
    }
    public static void main(String[] arg) {
	BookCompany company = new BookCompany();
	company.addBook("Algorithms in C",1998);
	company.addBook("Forth",1972);
	company.addBook("C",1988);
	company.addBook("C",1978);
	company.addBook("Discrete Math",1999);
	company.addBook("Algorithms",1990);
	company.addBook("Art of Computer Programming",1978);
	company.addBook("Fortran", 1965);
	company.addBook("The Practice of Programming", 1999);
	System.out.println("UnSorted Inventory:\n"+company);
	company.sortInventory();
	System.out.println("\nSorted Inventory: \n"+company);
    }

    static private class Book {
	String title;
	int year;
	static Comparator comparator = new BookComparator();
	Book (String title, int year) {
	    this.title = title;
	    this.year = year;
	}
	public String toString (){
	    return ("\n ("+title+ ","+ year+") ");
	}
	public boolean equals(Object obj){
	    // Assumes obj is of type Book
	    return (
		    (((Book)obj).title).equals(title)&& 
		    ((Book)obj).year==year);
	}
	/**
	   Nested classes in Java do not have access to 
	   instance variables of it's outer classes as well as it's own.
	   
	   Java can not pass functions like "C", however you can pass
	   objects and access the method through the object.  This allows
	   the code to be bound at runtime.
	**/
	static class BookComparator implements Comparator {
	    // 
	    public int compare (Object obj1, Object obj2){
		if (((Book)obj1).year < ((Book)obj2).year ) return -1;
		if (((Book)obj1).year > ((Book)obj2).year ) return 1;
		return (((Book)obj1).title).compareTo(((Book)obj2).title);
	    }
	}// end of BookComparator
    }// End of Book

}//End of Book Company


