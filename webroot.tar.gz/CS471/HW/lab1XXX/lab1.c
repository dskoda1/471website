#include <stdio.h>

 int xy,x,  char f; float f; 
 float arr[10];
 int i#rate = 10.99;
 
 int chg(int  flag)  {
      int struct = 8;
      int i = 3;
      xy=4;
      if (flag = 0) {
        arr[i] = 1.79766E+308;  
      } else {
        arr[10] = 1.9;  
      }
     return flag;
}
int main (void){   
      if (xy => 10) {  
        printf("Begin:: ");
      }
      chg(flag=0); 
      return  0;    
   } 

