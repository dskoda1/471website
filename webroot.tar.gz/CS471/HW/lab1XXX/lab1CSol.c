#include <stdio.h>
 
  char a1, b2;
  int arr[10];
  long fr, nx;
  long a;

  int main (void){
      int unio_n = 'a';
      a = 9;
      printf("Begin:: ");
      unio_n = chg(a);
      return 0;
    }
    int chg(long  fr)  {
        if (fr = 0) {
            float x = 10.99;  
            arr[10] = 10;
        } else {
            arr[1] = 1;
        }
     }
