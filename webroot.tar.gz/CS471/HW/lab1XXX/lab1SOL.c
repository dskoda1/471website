#include <stdio.h>
 int xy; char c; float rr;
 float arr[10];
 int irate = 10.99;
 
 int chg(int  flag)  {
      int typedefX = 8;
      int i = typedefX;
      xy = 4;
      i = 3;
      if (flag == 0) {
        arr[i] = 10.9;
      } else {
        arr[5] = 1.9;
      }
     return flag;
}
int main (void){   
      if (xy >= 10) {
        printf("Begin:: ");
      }
      return  0;    
   } 

