#include <stdio.h>
# syntactically correct.

 int xy; char fc; float f;
 float arr[10];
 int irate = 10.99;
 
 int chg(int  flag)  {
      int structX = 8;
      int i = 3;
      xy=4;
      if (flag = 0) {
        arr[i] = 3.40282347E-38F;
      } else {
        arr[10] = 1.9;
      }
     return flag;
}
int main (void){   
     int f;
      if (xy > 10) {
        printf("Begin:: ");
      }
      chg(f=0);
      return  0;    
   } 

