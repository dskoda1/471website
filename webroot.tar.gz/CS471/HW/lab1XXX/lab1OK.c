

#include <stdio.h>
 int xy, c ; float rr;
 float arr[10];
 int r2 = 10;
 int chg(int  charc)  {
     int i = 100;
     if (i == 0) {
 //        x = 10;  
         arr[i] = 10.9;
     } else {
          arr[10] = 1.9;
     }
     return charc;
 }
 int main (void){ 
     int next = 8;
     printf("Begin:: ");
//     next = i;
     chg(next);
     return  0;
                                                                      
  }
  

