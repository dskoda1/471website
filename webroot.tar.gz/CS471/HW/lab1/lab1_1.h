int  powerI(int pow, int base);
/* add the below statement to the header file */
/* int  powerR(int pow, int base); */

