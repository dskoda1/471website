#include <stdio.h>
 
  char a1; b2;
  int arr[10]
  long f#r, nx;
  long a;

  int main (void){
      int union = 'a';
      float x;
      a = 9;
      printf("Begin:: ");
      union = chg(a);
      return 0;
    }
    int chg(long  fr)  {
        if (fr = 0) {
            x = 10.99;  
            arr[10] = 10;
        } else {
            arr[1] = 1;
        }
     }
