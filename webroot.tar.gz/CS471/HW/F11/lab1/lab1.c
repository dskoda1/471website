#include <stdio.h>
 int _Flag = 0;
 int xy; char c , float rr;
 int arr#1[10];
 int _Bool;

 int chg(int  flag)  {
     if (flag = _Flag) {
         y = 33;   
         arr#1[10] = 10;
     } else {
          arr[10] = 1.9;
     }
     return flag;
 }
 int main (void){ 
     int sizeof = 100;
     printf("Begin:: ")
     _Flag = chg(xy);
     return 0;                                                                 
  }


