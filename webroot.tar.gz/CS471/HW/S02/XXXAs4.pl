/*
        CS471 - Programming Languages
        Section: <YOUR Section number>
        Assignment #<number> due: <DATE>
        Author: <LastName>, <FirstName> (<EMail>)
        Date: <DATE>
*/


%1 deleteE(Lst1, Lst2).


%2 bagToSet(Bag,Set).


%3 palindrome(List).


%4 myMerge(+Lst1, +Lst2, -Result).



%5 partition(+Lst, -Part1, -Part2).


%6 mergesortX(+UnsortedLst, -Sorted).

%7 mapcolor(A,B,C,D,E,F).


%8 ack ...
