/*
        CS471 - Programming Languages
        Section: <YOUR Section number>
        Assignment #<number> due: <DATE>
        Author: <LastName>, <FirstName> (<EMail>)
        Date: <DATE>
*/

%1. pair(X,Y,P)


%2a. averIT(+X,+Y,?A).



%2b. averIT((+X,+Y),?A).


%2c. averIT([+X,+Y],?A).


%3. secondE(Lst1,Lst2). 



%4. maxList(Max,+Lst).


%5. lenList(LstofLsts, Len).



%6. sameLen(Lst1ofLsts, Lst2ofLsts).


%7. zip(Z,X,Y)


%8. zipList(Lst1,Lst2,ZLst).

 
%9. predList(LstofLst,LstofPred).


%10.applyList(Lst).
 


