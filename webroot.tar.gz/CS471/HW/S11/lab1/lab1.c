#include <stdio.h>
 int xy; char c , float rr;
 float arr[10]
 float r!r = 10.99;
 int chg(int  flag)  {
     if (flag = 0) {
         x = 10.99;   
         arr[10] = 10.9;
     } else {
          arr[10] = 1.9;
     }
     return flag;
 }
 int main (void){ 
     int signof = 8;
     printf("Begin:: ");
     signof = chg(xy);
     return 0;                                                                 
  }


