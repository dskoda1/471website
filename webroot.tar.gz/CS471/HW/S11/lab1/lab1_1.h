int  gcdI(int i, int j);
/* add the below statement to the header file */
/* int  gcdR(int i, int j); */

