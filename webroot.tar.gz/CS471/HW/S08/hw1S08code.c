    #include <stdio.h>
    int arr[10]
    float english#student = 5.5;
    int chg(int  flag)  {
        if (flag = 0) {
            english#student = 10;    
            arr[10] = 10;
        } else {
            arr[10] = 1;
       }
    }
    int main (void){  
       int default = 10;
       printf("Begin:: ");
       chg(default);
       chg(next);

       return 0;                                                                  
    }
