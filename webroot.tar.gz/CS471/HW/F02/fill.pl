fill(X,N,L):-length(L,N),append(L,[X],[X|L]).
