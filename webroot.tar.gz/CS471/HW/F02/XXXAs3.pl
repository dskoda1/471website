/*
        CS471 - Programming Languages
        Section: <YOUR Section number>
        Assignment #<number> due: <DATE>
        Author: <LastName>, <FirstName> (<EMail>)
        Date: <DATE>
*/

%1. mkTuple(X, Y, P).
% CODE to follow:




%2. mkZip(Z,X,Y).




%3. addV(V,Lst,RLst).





%4. hasDuplicate(Lst).



%5.   secondElement(Lst, Element).



%6.   isIncreasing(Lst).



%7.   tupleLists(L, M, P).


%8.   numOfElements(LstOfLsts, Number).



%9. funmap(Functor,ListOfArgs,ListOfTerms).




%10. applylist(L)
