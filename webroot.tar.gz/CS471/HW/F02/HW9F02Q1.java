package hw9;

/**
 * @author head
 * use the -d option to compile 
 * to execute type
 * java hw9.HW9F02Q1
 */
public class HW9F02Q1 {
    
    public static void main(String[] args) {
	System.out.println( 1 +1 + "=" +1 +1);
	System.out.println( "Answer is:" + 1 +1 + "=" +1 +1);

    }
}
